from turtle import up

import self
from poco import poco
from poco.drivers.android.uiautomation import AndroidUiautomationPoco
from airtest.core.api import *

import ZSB_Mobile.TestExecution.test_Help
import ZSB_Mobile.TestExecution.test_App_Settings
from ZSB_Mobile.Common_Method import Common_Method
from ZSB_Mobile.PageObject.Login_Screen import *

from ZSB_Mobile.PageObject.Add_A_Printer_Screen import Add_A_Printer_Screen
from ZSB_Mobile.PageObject.APP_Settings_Screen import App_Settings_Screen
from ZSB_Mobile.PageObject.Help_Screen import Help_Screen
from ZSB_Mobile.Common_Method import Common_Method
from ZSB_Mobile.PageObject.Login_Screen import Login_Screen


class Android_App_Help:
    pass


poco = AndroidUiautomationPoco(use_airtest_input=True, screenshot_each_action=False)

connect_device("Android:///")
start_app("com.zebra.soho_app")
sleep(2.0)

common_method = Common_Method()
login_page = Login_Screen(poco)
app_settings_page = App_Settings_Screen(poco)
add_a_printer_screen = Add_A_Printer_Screen(poco)
help_page = Help_Screen(poco)

def test_Help_TestcaseID_45789():
    """""""""test"""""


"""""""""click on the login button"""""""""""
# login_page.click_loginBtn()
# sleep(2)
# """""""select the login with google option"""""""""
# login_page.click_Loginwith_Google()
# sleep(2)
# login_page.click_GooglemailId()
# sleep(5)
# login_page.add_Account()
# sleep(2)
# login_page.Enter_Google_UserID()
# sleep(2)
# login_page.click_Emailid_Nextbtn()
# sleep(4)
# """"To enter password need to use the 2nd method """
# login_page.Enter_Google_Password()
# # poco(text("Swdvt@#123"))
# # sleep(2)
# login_page.click_Password_Nextbtn()
# sleep(7)
# help_page.chooseAcc()
# sleep(5)
"""Click hamburger icon to expand menu"""
login_page.click_Menu_HamburgerICN()
sleep(2)
"""Swipe up"""
poco.scroll()
sleep(2)
"""Check Help icon with '?' is present"""
help_page.checkIfHelpIconIsPresent()
"""Click Help dropdown to expand Help options"""
help_page.click_Help_dropdown_option()
sleep(2)
"""Check Help has Support, FAQs, Contact Us and Live Chat Options"""
# help_page.verify_text("Live Chat", help_page.Chat_btn)
help_page.Test_Support_faq_Contactus__Livechat_is_present()
"""Click Support to open support page"""
help_page.click_Support()
sleep(5)
"""Check if we are redirected to support page"""
help_page.checkIfLandedOnSupportPage()
common_method.swipe_screen([1, 0.3482905982905983], [0.22037037037037038, 0.3482905982905983], 1)
"""Click FAQs to see FAQ on the web"""
help_page.click_FAQs()
sleep(5)
"""Check if we are redirected to FAQs page"""
help_page.checkIfLandedOnFAQsPage()
common_method.swipe_screen([1, 0.3482905982905983], [0.22037037037037038, 0.3482905982905983], 1)
sleep(2)
"""Click Contact US to view contact options"""
help_page.click_ContactUs()
sleep(5)
"""Check if we are redirected to Contact Us page"""
help_page.checkIfLandedOnContactUsPage()
common_method.swipe_screen([1, 0.3482905982905983], [0.22037037037037038, 0.3482905982905983], 1)
"""Click chat to """
help_page.click_Chat()
sleep(5)
"""Click Begin Chat"""
help_page.clickBeginChat()
sleep(2)
"""Yet to verify chat"""


def test_Help_TestcaseID_47788():
    """""""""test"""""


# """""""""click on the login button"""""""""""
# login_page.click_loginBtn()
# sleep(2)
# """""""select the login with google option"""""""""
# login_page.click_Loginwith_Google()
# sleep(2)
# login_page.click_GooglemailId()
# sleep(5)
# login_page.add_Account()
# sleep(2)
# login_page.Enter_Google_UserID()
# sleep(2)
# login_page.click_Emailid_Nextbtn()
# sleep(4)
# """"To enter password need to use the 2nd method """
# login_page.Enter_Google_Password()
# # poco(text("Swdvt@#123"))
# # sleep(2)
# login_page.click_Password_Nextbtn()
# sleep(7)
"""Click hamburger icon to expand menu"""
login_page.click_Menu_HamburgerICN()
sleep(2)
"""Swipe up"""
poco.scroll()
sleep(2)
"""Click Help dropdown to expand Help options"""
help_page.click_Help_dropdown_option()
# poco(name="Help").click()
sleep(2)
"""Click Live Chat"""
help_page.click_Chat()
sleep(2)
"""Check if it displays Available 7am to 7pm ET"""
try:
    help_page.verifyChatHours()
except AssertionError as e:
    print(e)
sleep(2)
"""Begin Chat"""
help_page.clickBeginChat()
sleep(2)
"""Click Back Arrow"""
help_page.clickBackArrow()
sleep(2)
"""Check if it displays Available 7am to 7pm ET"""
"""Unable to verify due to BUG"""
try:
    help_page.verifyChatHours()
except AssertionError as e:
    print(e)
sleep(2)
