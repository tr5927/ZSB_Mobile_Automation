#from poco import poco
import time
from airtest.core.api import *
from poco.drivers.android.uiautomation import AndroidUiautomationPoco
from ZSB_Mobile.PageObject.Login_Screen import Login_Screen
from ZSB_Mobile.PageObject.Others import Others

class test_Others():
    pass


poco = AndroidUiautomationPoco(use_airtest_input=True, screenshot_each_action=False)

connect_device("Android:///")
start_app("com.zebra.soho_app")
sleep(3.0)

login_page = Login_Screen(poco)
others = Others(poco)



def test_Others_TestcaseID_47972():
    pass

login_page.click_Menu_HamburgerICN()

sleep(1)

""" Select the Printer Settings """
others.click_Printer_Settings()

others.swipe_left()
""" Select a printer """
others.click_selected_printer()
sleep(2)

""" Click on the icon """
others.click_icon()
sleep(1)

"""Click On the Demo video"""
others.click_demo_video()
sleep(5)

"""Close The Demo Video"""
others.close_demo_video()


def test_Others_TestcaseID_49203():
    pass

"""Click On the Three dots of the Home page Printer"""
others.click_three_dots()

"""Click on the Delete Button"""
others.click_delete_button()

"""Verify the text image (Currently The text cannot be extracted so verifying using the name)"""
others.verify_delete_printer_text()

"""Check cancel and delete button exists"""
others.check_cancel_and_delete_button()

"""cancel the delete printer dialogue"""
others.click_cancel_delete_printer()


def test_Others_TestcaseID_47946():
    pass

"""take the prvious number of cartridges"""
previous = others.get_no_of_left_cartridge()
print(previous)

"""click on navigation option"""
login_page.click_Menu_HamburgerICN()

"""Select the Printer in the Printer Settings (Note: The printer name should be defined)"""
others.click_Printer_Settings()
others.click_selected_printer()
sleep(2)
n=2

"""test the printer to print the label"""
for i in range(n):
    others.click_test_print()
    sleep(2)

sleep(1)
"""Go to the Home Page"""
login_page.click_Menu_HamburgerICN()
others.click_home_button()
sleep(2)

"""After printing Get the number of cartridges"""
after = others.get_no_of_left_cartridge()
print(after)

"""Check wheather the cartridges are updated"""
res = others.check_auto_update_cartridge(previous,after,n)
if res:
    print("success")
else:
    print("Failed")


"""BELOW NEED TO BE COMPLETED"""


def test_Others_TestcaseID_45793():
    pass

# print("hello")
# start_app("com.google.android.googlequicksearchbox")
#
# others.click_google_search_bar()
# others.enter_the_text_in_goole("https://zsbportal.zebra.com/")
# others.click_enter()
# sleep(5)
# login_page.click_Loginwith_Google()
# sleep(4)
# login_page.click_swdvt_account()
# sleep(5)
# others.click_hamburger_button_in_Google()
# sleep(2)
# others.click_Printer_Settings()
# others.click_hamburger_button_in_Google()
#
#
# others.click_selected_printer_in_google()
#
# others.google_scroll_down()
# others.click_google_print_test_button()
# sleep(10)
#
# #others.change_Darkness_level_in_google(50)
#
# others.click_hamburger_button_in_Google()
#
# others.click_notifications_button_in_google()
#
# others.click_hamburger_button_in_Google()
#
# google_notification = others.get_notification_text_in_google()
# print(google_notification)
# sleep(2)
#
# start_app("com.zebra.soho_app")
# sleep(10)
# #
# login_page.click_Menu_HamburgerICN()
# others.click_notifications_button()
#
# Android_notification = others.get_notification_text_in_Android()
# sleep(3)
#
# # res = others.verify_notifications(google_notification,Android_notification)
# # print(res)


























































